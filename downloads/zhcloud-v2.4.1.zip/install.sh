#!/bin/bash

# 设置颜色变量以便更好的输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 检查是否以 root 用户运行
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}请以 root 权限运行此脚本${NC}"
  exit 1
fi

# 定义源目录和目标目录
SOURCE_DIR="./" # 替换为你的项目路径
TARGET_DIR="/Volumes/D/opt/zhcloud" #mac下为/Volumes/D/opt/zhcloud，linux：/opt/zhcloud

# 复制项目文件到目标目录
echo -e "${YELLOW}正在将项目文件复制到 ${TARGET_DIR}${NC}"
cp -r $SOURCE_DIR $TARGET_DIR
if [ $? -ne 0 ]; then
  echo -e "${RED}复制文件失败${NC}"
  exit 1
fi

# 导航到目标目录
cd $TARGET_DIR || { echo -e "${RED}无法进入目标目录${NC}"; exit 1; }

# 启动 Docker Compose 服务
echo -e "${YELLOW}正在启动 Docker Compose 服务${NC}"
docker-compose -f AllInOne.yml up -d
if [ $? -ne 0 ]; then
  echo -e "${RED}启动 Docker Compose 服务失败${NC}"
  exit 1
fi

# 修改 MySQL 配置以允许远程连接
echo -e "${YELLOW}正在配置 MySQL 允许远程连接${NC}"
MYSQL_ROOT_PASSWORD="Zhtec@12345" # 确保这是你的真实密码
MYSQL_USER="root"
MYSQL_HOST="%"
MYSQL_PORT="3306"
MYSQL_DATABASE="zhcloud-db"
SQL_FILE="/tmp/initdb.d/zhcloud.sql"
SQL_FILE_CONFIG="/tmp/initdb.d/config_data.sql"

# 等待 MySQL 容器启动并准备好接受连接
echo -e "${YELLOW}等待 MySQL 容器准备就绪...${NC}"
until docker exec -it mysql bash -c "mysqladmin -uroot -p$MYSQL_ROOT_PASSWORD ping --silent"; do
  sleep 2
done
echo "MySQL容器已就绪!"

# 更新 MySQL 配置以允许远程连接（适用于本地 MySQL）
# 注意：如果你使用的是远程 MySQL，则不需要这一步
# 修改 MySQL 配置以允许远程连接
echo -e "${YELLOW}正在配置 MySQL 允许远程连接...${NC}"
# 不断尝试执行ALTER USER语句，直到成功
while true; do
    # 执行ALTER USER语句，这里示例修改root用户密码，你可根据实际需求修改ALTER USER内容
    result=$(docker exec -it mysql bash -c "mysql -uroot -p$MYSQL_ROOT_PASSWORD -e \"
             ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '$MYSQL_ROOT_PASSWORD';
             CREATE USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY '$MYSQL_ROOT_PASSWORD';
             GRANT ALL PRIVILEGES ON *.* TO 'root'@'%' WITH GRANT OPTION;
             FLUSH PRIVILEGES;\"" 2>&1)
     echo "ALTER USER 命令执行成功."
     sleep 5
     break
#    if [ $? -eq 0 ]; then
#        echo "ALTER USER 命令执行成功."
#        break
#    else
#        echo "ALTER USER 命令执行尚未成功. 2秒后重试..."
#        sleep 2
#    fi
done


# 对于远程 MySQL，确保防火墙允许访问并且 MySQL 配置允许远程连接。
# 这里我们假设 MySQL 已经配置好允许远程连接，下面只是更新环境变量

# 更新 docker-compose.yml 文件中的 MySQL 主机为远程地址
#REMOTE_MYSQL_HOST="your.remote.mysql.host" # 替换为实际的远程 MySQL 主机
#sed -i "s|MYSQL_HOST:.*|MYSQL_HOST: $REMOTE_MYSQL_HOST|" $TARGET_DIR/docker-compose.yml
#sed -i "s|SPRING_DATASOURCE_DRUID_MASTER_URL:.*|SPRING_DATASOURCE_DRUID_MASTER_URL: jdbc:mysql://$REMOTE_MYSQL_HOST:$MYSQL_PORT/$MYSQL_DATABASE?useSSL=false&serverTimezone=UTC|" $TARGET_DIR/docker-compose.yml

# 重启 Docker Compose 服务以应用更改
#echo -e "${YELLOW}正在重启 Docker Compose 服务以应用更改${NC}"
#docker-compose  restart -f AllInOne.yml
#if [ $? -ne 0 ]; then
#  echo -e "${RED}重启 Docker Compose 服务失败${NC}"
#  exit 1
#fi

# 导入 SQL 初始数据到 MySQL 数据库
echo -e "${YELLOW}正在导入 SQL 初始数据...${NC}"
docker exec -i mysql bash -c "mysql -u$MYSQL_USER -p$MYSQL_ROOT_PASSWORD $MYSQL_DATABASE < $SQL_FILE"
if [ $? -ne 0 ]; then
  echo -e "${RED}导入 SQL 数据失败${NC}"
  exit 1
fi

docker exec -i mysql bash -c "mysql -u$MYSQL_USER -p$MYSQL_ROOT_PASSWORD $MYSQL_DATABASE < $SQL_FILE_CONFIG"
if [ $? -ne 0 ]; then
  echo -e "${RED}导入 SQL 配置数据失败${NC}"
  exit 1
fi

echo -e "${GREEN}安装完成！${NC}"